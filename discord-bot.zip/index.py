import discord
from discord.ext import commands
from keep_alive import keep_alive  # Import keep_alive

# Define the necessary intents
intents = discord.Intents.default()  # Allow the bot to read message content
intents.message_content = True  # Make sure this is enabled if you're reading messages

# Create the bot with the intents
bot = commands.Bot(command_prefix='!', intents=intents)

# This event triggers when the bot is ready
@bot.event
async def on_ready():
    print(f'Logged in as {bot.user}')

# Log incoming messages (for debugging purposes)
@bot.event
async def on_message(message):
    # Make sure the bot doesn't respond to its own messages
    if message.author == bot.user:
        return

    print(f"Received message: {message.content}")  # Log the message content

    # Process the command (this allows the bot to respond to commands)
    await bot.process_commands(message)

# Define the !ping command
@bot.command()
async def ping(ctx):
    print("Ping command received!")  # Log when the command is received
    await ctx.send('Pong!')

# Keep the bot alive using Flask
keep_alive()

# Run the bot
bot.run('MTI5NjQ5NzQxMzQ0NzQ4MzQzMw.G0_9JM.JWbRAZBsjskOaUl0t3eRhhQZVzdKzQC7gmtVuo')  # Replace with your bot's token
